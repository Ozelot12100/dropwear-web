---
name: High-Performance Apparel Operations
colors:
  surface: '#f9f9f7'
  surface-dim: '#dadad8'
  surface-bright: '#f9f9f7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f4f2'
  surface-container: '#eeeeec'
  surface-container-high: '#e8e8e6'
  surface-container-highest: '#e2e3e1'
  on-surface: '#1a1c1b'
  on-surface-variant: '#47464a'
  inverse-surface: '#2f3130'
  inverse-on-surface: '#f1f1ef'
  outline: '#77767b'
  outline-variant: '#c8c5ca'
  surface-tint: '#5f5e60'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1b1b1d'
  on-primary-container: '#858386'
  inverse-primary: '#c8c6c8'
  secondary: '#bb001e'
  on-secondary: '#ffffff'
  secondary-container: '#e32130'
  on-secondary-container: '#fffbff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1e1b18'
  on-tertiary-container: '#88837e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e1e4'
  primary-fixed-dim: '#c8c6c8'
  on-primary-fixed: '#1b1b1d'
  on-primary-fixed-variant: '#474649'
  secondary-fixed: '#ffdad7'
  secondary-fixed-dim: '#ffb3ae'
  on-secondary-fixed: '#410004'
  on-secondary-fixed-variant: '#930015'
  tertiary-fixed: '#e8e1dc'
  tertiary-fixed-dim: '#cbc5c0'
  on-tertiary-fixed: '#1e1b18'
  on-tertiary-fixed-variant: '#4a4642'
  background: '#f9f9f7'
  on-background: '#1a1c1b'
  surface-variant: '#e2e3e1'
  surface-bone: '#F7F7F5'
  surface-pure: '#FFFFFF'
  ink-text: '#0E0E10'
  hairline-border: '#E7E7E4'
  status-available: '#10B981'
  status-reserved: '#F59E0B'
  status-sold: '#3B82F6'
  status-returned: '#EF4444'
typography:
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.4'
  mono-data:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: -0.01em
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base-unit: 4px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  max-width: 1200px
---

## Brand & Style

The design system embodies a "Premium Operational Tool with a Clothing Brand Soul." It balances the ruthless efficiency required for high-frequency inventory management with the edgy, high-contrast aesthetic of modern streetwear and tech-forward platforms like Linear or Vercel.

The visual direction is **Minimalist and High-Contrast**. It uses a sophisticated "Bone" canvas to reduce eye strain during long operational shifts while maintaining a premium feel. The UI should feel fast, responsive, and authoritative. It prioritizes clarity and speed of interaction—essential for floor staff—while using bold typography and a singular brand accent to reflect a young, contemporary identity.

The emotional response is one of **speed, precision, and reliability**. It is a tool for making money and managing assets, stripped of unnecessary decorative elements but elevated through meticulous spacing and "hairline" precision.

## Colors

The palette is rooted in a high-contrast monochromatic base, accented by a vibrant brand red derived from the logo and a functional status system.

- **Primary (Negro Tinta):** Used for primary actions, main headings, and active navigation states.
- **Accent (Logo Red):** A bold red used sparingly for focus states, key data highlights, and brand-specific links.
- **Surface Strategy:** A "Bone" (#F7F7F5) background provides a soft foundation, while "Pure White" (#FFFFFF) is reserved for cards and input fields to create immediate depth.
- **Status System:** Critical for operations, these use a dot + label pattern.
    - **Disponible:** Emerald Green for positive inventory flow.
    - **Apartado:** Amber for pending transactions.
    - **Vendido:** Cold Blue for finalized deals.
    - **Devuelto:** Red/Rose for attention and reversal.

## Typography

The typographic system utilizes three distinct typefaces to separate hierarchy and function:

1.  **Space Grotesk (Headlines):** Used for page titles and section headers. Its geometric, slightly eccentric forms give the "clothing brand" soul to the interface.
2.  **Inter (Body/UI):** The workhorse for all operational data, forms, and secondary text. It ensures maximum legibility at small sizes on mobile devices.
3.  **JetBrains Mono (Data/Prices):** Used exclusively for currency (MXN), ID numbers, and quantities. Tabular figures ensure that numbers align perfectly in lists and tables, facilitating quick scanning of financial data.

All typography must adhere to WCAG AA contrast ratios against the Bone or White backgrounds.

## Layout & Spacing

This design system uses a **Fluid Grid** for mobile-first operations and a **Constrained Fixed Grid** (max-width 1200px) for desktop administration.

- **Mobile Rhythm:** A 4px base unit informs all spacing. Touch targets are strictly ≥44px to accommodate one-handed use on the sales floor. Side margins are 16px.
- **Desktop Rhythm:** A 12-column grid with 24px gutters. Content is centered to prevent visual drift on wide monitors.
- **Density:** The spacing is "generous but efficient." It uses whitespace to separate items rather than heavy lines, though "hairline" (#E7E7E4) borders are used for card definition and table rows.

## Elevation & Depth

Hierarchy is established through **Tonal Layering and Low-Contrast Outlines** rather than heavy shadows.

- **Surface Tiers:** Background is Bone (#F7F7F5). Interactive cards and containers are Pure White (#FFFFFF). This creates a natural "lift" without needing shadows.
- **Borders:** "Hairline" borders (1px) in #E7E7E4 are the primary method of containment. They should feel sharp and technical.
- **Shadows:** Use only one shadow level—a very soft, diffused ambient shadow (0px 4px 12px rgba(0,0,0,0.03))—reserved exclusively for floating elements like Modals or Dropdowns.
- **Micro-feedback:** Upon press, elements scale to 0.98, providing tactile confirmation of an action.

## Shapes

The shape language is "Moderately Rounded," striking a balance between the technical feel of sharp corners and the approachable feel of pill shapes.

- **Cards:** 16px radius for large containers.
- **Buttons & Inputs:** 10px - 12px radius. This is the "sweet spot" for a modern, premium tool.
- **Chips/Badges:** Fully rounded (pill) to distinguish them from interactive buttons.
- **Status Indicators:** 8px circles (dots) used within badges.

## Components

- **Buttons:**
    - **Primary:** Solid Negro Tinta (#0E0E10) with white text. High impact.
    - **Secondary/Outline:** Hairline border (#E7E7E4) with Ink text.
    - **Destructive:** Light red wash background with status-returned text.
- **Cards:** White backgrounds, hairline borders, 16px padding. In inventory lists, cards include a 4px vertical "status bar" on the far left edge (color-coded by status).
- **Inputs:** 12px radius, hairline border. Focus state uses a 2px ring in the brand red accent.
- **Chips:** Used for Status and Sizes.
    - Status chips must include a colored dot (e.g., Emerald dot for "Disponible").
    - Size chips use Mono typography and a light grey background.
- **Navigation:**
    - **Mobile:** Fixed bottom Tab Bar with 5 icons. Active state is Negro Tinta.
    - **Desktop:** Clean top bar. Logo on left, nav links centered, user profile on right.
- **Modals:** Slide up from bottom on mobile; centered with a dim backdrop (20% opacity black) on desktop.